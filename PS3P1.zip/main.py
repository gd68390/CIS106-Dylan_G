#Input Phase
StockSymbol = input("Enter Stock Symbol: ")
ShareAmount = float(input("Enter Amount of Shares Owned: "))
CostPerShare = float(input("Enter Cost per Share: "))

#Processing Phase
AmountInvested = ShareAmount * CostPerShare

#Output Phase
print("Amount Invested $", AmountInvested)
